/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fonts.h"      // OLED ?��?��?��?��?��?��?�� ?��?��?��?�� ?��?�� ?��?��브러�?
#include "ssd1306.h"    // SSD1306 OLED ?��?��?��?��?�� ?��?�� ?��?��브러�?
#include <stdio.h>       // 문자?�� ?��맷팅?�� ?��?�� ?���? ?��?��브러�?

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX_PWM 2000 // PWM ???�� ?��?��?��?�� 최�?�??
#define ADC_MIN 1000 // ADC 값의 최소�??
#define ADC_MAX 4000 // ADC 값의 최�?�??

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
char oled_buffer[30];    // OLED 출력 문자?�� 버퍼
uint16_t readValue = 0;  // ?��?�� ADC ?���?? �?? ???�� �???��
uint16_t lastReadValue = 0; // ?��?�� ADC �?? ???�� �???��

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/**
  * @brief PWM ?��?��?��?�� ?��?��
  * @param adcValue ADC �??? (0~4095)
  */
void Update_PWM(uint16_t adcValue)
{
    // ADC 값을 PWM 값으�??? ?��규화 (ADC_MIN ~ ADC_MAX?�� 비�?)
    if (adcValue < ADC_MIN) adcValue = ADC_MIN; // 최소�??? ?��?��
    if (adcValue > ADC_MAX) adcValue = ADC_MAX; // 최�?�??? ?��?��

    uint16_t dutyCycle = ((adcValue - ADC_MIN) * MAX_PWM) / (ADC_MAX - ADC_MIN); // ?��규화 계산
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, dutyCycle); // ?��규화?�� ???�� ?��?��?�� ?��?��
}

/**
  * @brief OLED 출력 ?��?��?��?�� ?��?��
  * @param adcValue ADC �???
  */
void Update_OLED(uint16_t adcValue)
{
    SSD1306_GotoXY(0, 0); // ?��면의 (0, 0) ?��치로 커서 ?��?��
    SSD1306_Puts("LDR", &Font_11x18, 1); // "LDR" ?��?��?�� 출력

    SSD1306_GotoXY(0, 20); // ?��면의 (0, 20) ?��치로 커서 ?��?��
    sprintf(oled_buffer, "%d", adcValue); // ADC 값을 문자?���??? �????��
    SSD1306_Puts(oled_buffer, &Font_11x18, 1); // �????��?�� 문자?�� 출력

    SSD1306_UpdateScreen(); // OLED ?���??? 갱신
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_I2C3_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  // ???���?? 주기 ?��?�� (PWM 최�?값에 맞게 조정)
   htim3.Init.Period = MAX_PWM - 1; // PWM 최�?값을 기반?���?? ???���?? 주기 ?��?��
   HAL_TIM_PWM_Init(&htim3);        // ???���?? ?��?�� 반영

   // ?��?��?�� 초기?��
   SSD1306_Init(); // SSD1306 OLED 초기?��
   SSD1306_Clear(); // OLED ?���?? 초기?��
   HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3); // ???���?? 3 PWM 채널 ?��?��

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	   /* ADC 값을 ?��?��?���? */
	    HAL_ADC_Start(&hadc1); // ADC �??�� ?��?��
	    HAL_ADC_PollForConversion(&hadc1, 100); // �??�� ?���? ??�? (최�? 100ms)
	    readValue = HAL_ADC_GetValue(&hadc1); // �??��?�� ADC �? ?���?

	    /* PWM ?��?��?��?�� */
	    Update_PWM(readValue); // ?��?? ADC 값을 기반?���? PWM ???�� ?��?��?�� ?��?��

	    /* OLED ?��?��?��?�� (�? �?�? ?���?) */
	    if (readValue != lastReadValue) { // ADC 값이 ?��?�� 값과 ?���? ?���? ?��?��?��?��
	        Update_OLED(readValue); // OLED ?���? 갱신
	        lastReadValue = readValue; // ?��?�� �? ?��?��?��?��
	    }

	    HAL_Delay(100); // 100ms �??�� (?��?�� 루프�? ?��?�� ??�?)
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
